# BYTE NDT — Atelier unifié : mode d’emploi

**Auteurs / Authors : Jean-Michel Puybouffat et Fabien Dedieu.**
© 2026 Jean-Michel Puybouffat & Fabien Dedieu. Les composants tiers conservent leurs licences et attributions. / Third-party components retain their respective licences and credits.


Version revue le 7 novembre 2026. Fichier : BYTE_NDT_ATELIER_REVUE.html. Guide établi à partir du fichier fourni par Fabien et de tests Chromium ; une recette sur votre poste reste nécessaire.

## 1. Démarrer

Décompresser le dossier et ouvrir le HTML dans Chrome ou Edge récent sur ordinateur. Aucun serveur UT n’est nécessaire pour la simulation. Pour une installation partagée et les fonctions caméra/USB, privilégier un hébergement HTTPS ; localhost convient au développement. Ne pas supprimer les scripts et données embarqués. Les liens externes vers Streamlit ou la documentation demandent Internet.

FR/EN, en haut à droite, change la langue. Le bouton Guide décrit les possibilités et leurs limites. La scène 3D est manipulable à la souris ; Plan permet une lecture à plat. Un poste sans WebGL peut basculer en plan.

## 2. Choisir une pièce et une sonde

Ouvrir Bibliothèque de pièces. Filtrer par famille ou rechercher une pièce. Le catalogue contient 40 configurations, 19 matériaux et 15 profils de sonde. Charger une pièce pour une exploration libre ; Exercice aveugle démarre une recherche avec référence cachée. Le chargement d’une nouvelle pièce change la configuration active : exporter le travail à conserver avant de changer de cas.

Les familles comprennent tôles, soudures planes, tubes, soudures de tubes, piquages, barres, disques et volumes maillés. Les modèles paramétriques ne sont pas une copie automatique de vos CAO industrielles.

Choisir SE 0°, MWB ou PA32, puis le profil dans Avancé / Bibliothèque de sondes. Régler fréquence, angle, dimensions du sabot, portes temporelles et gamme selon le scénario. Les vitesses acoustiques sont nominales ; le modèle ne valide pas une procédure de contrôle réelle. Une valeur pédagogique de boîtier n’est pas une fiche constructeur.

## 3. Déplacer et acquérir

En mode Souris & clavier, glisser sur la pièce ou sur le plan. Flèches : translation ; Q/E : orientation ; Maj + flèches : déplacement plus grand. Molette : zoom ; clic droit ou mode rotation : orientation de la vue. Espace mémorise une réponse lorsque le contact est admissible.

Acquérir enregistre selon le pas spatial : l’immobilité ne crée pas une ligne de balayage. Balayage raster lance un parcours automatique ; régler ses limites, pas, index et vitesse dans Parcours. STOP arrête mouvement et acquisition. Les positions hors contact géométrique ne sont pas acquises.

Le sabot doit rester sur une zone admise par la géométrie. La valeur « positions visitées » décrit l’échantillonnage spatial, pas une preuve de couverture acoustique complète.

## 4. Lire les écrans

- A-scan : réponse en fonction du temps, enveloppe ou RF ; cliquer pour positionner le curseur. La porte A sélectionne une plage de temps et un seuil.
- S-scan : secteur pour PA ; en SE/MWB, coupe monoangle. Cliquer dans un secteur PA sélectionne un rayon.
- B-scan : profils acquis suivant le trajet.
- C-scan : amplitude dans la porte A aux positions acquises.

La profondeur affichée est reconstruite selon un trajet supposé. Une réponse unique ne détermine pas à elle seule la position et la nature réelles d’un défaut. La transparence et les indications formateur aident à comprendre la géométrie.

Le badge de provenance distingue les signaux calculés des signaux instrument reçus. Un suivi de position réel ne transforme pas un signal calculé en mesure UT réelle.

## 5. Exercice aveugle

Choisir Exercice aveugle, pièce, difficulté et objectif. Lire la consigne ; vérifier le montage et acquérir au moins huit positions distinctes pour permettre la remise. Ajouter les indications proposées avec XYZ, nature, longueur, confiance et commentaire. Remettre le relevé pour obtenir la correction pédagogique, puis éventuellement afficher la référence.

Un relevé vide peut être remis après acquisition ; il obtient un résultat en fonction des indications réellement présentes. La note compare le relevé à la référence du scénario ; ce n’est ni une qualification opérateur ni une décision d’acceptation de pièce. Le HTML local ne sécurise pas un examen : son code peut être inspecté.

## 6. Rapport, export et reprise

Rapport contient opérateur, procédure, observations et réponses mémorisées. Exporter :

- JSON : conservation des séries et profils ; format à utiliser pour reprendre une session.
- CSV : tableau des acquisitions et leur provenance.
- PNG : copie des quatre écrans UT, pas une capture complète de la scène 3D.
- Imprimer / PDF : rapport imprimable depuis le navigateur.

Sans vérité formateur, le JSON s’ouvre en relecture. Pour reprendre une session complète avec sa référence, exporter en formation avec la vérité activée. La vérité n’est pas fournie dans les exports courants d’examen. Garder séparées les copies formateur et stagiaire.

Les réglages et le texte du rapport sont mémorisés dans le navigateur ; les acquisitions ne sont pas conservées par un simple rechargement. Exporter le JSON avant de fermer, actualiser ou changer de machine. L’effacement des données du navigateur supprime la persistance locale.

## 7. Caméra : geste réel, palpeur virtuel

Ouvrir Suivi et Activer caméra ; autoriser la caméra. Choisir index ou marqueur coloré. Fixer la caméra et définir les quatre coins du plan dans l’ordre indiqué : origine, coin X, coin X/Y, coin Y. Entrer les dimensions réelles du plan. Suivre les consignes du panneau pour le marqueur.

Le plan doit rester fixe, visible et convenablement éclairé. Tester un déplacement de longueur connue et le retour à l’origine. Vérifier axes, orientation et effet miroir avant d’acquérir. Refaire le calibrage après tout déplacement de caméra ou de référence. La perte de suivi doit arrêter l’acquisition ; la tester intentionnellement avant une démonstration.

La webcam commande XY ; Z et le contact sont contraints, non mesurés. Sur un tube/piquage, elle commande le développé : elle ne mesure pas la surface courbe en 3D. Le suivi et ses modèles sont traités localement dans le fichier fourni. Le test de revue a utilisé une caméra synthétique : la précision avec votre caméra et votre main reste à mesurer.

## 8. Capteur externe et instrument UT

Dans Entrées, choisir un adaptateur USB série ou une passerelle WebSocket. Chrome/Edge et un contexte sécurisé sont recommandés pour Web Serial. L’instrument propriétaire nécessite un adaptateur conforme au protocole ; aucun appareil n’a été validé pendant cette revue.

Sélectionner Capteur externe avant d’appeler window.ByteNDT.applyTrackedPose ou applyAcquisition. Un paquet doit inclure une séquence croissante, timestamp_ms fini et croissant, position_mm XYZ, orientation, face et confiance suffisante. Utiliser les exemples de l’onglet Entrées. Spécifier timestamp_clock pour une horloge epoch ; conserver une base monotone cohérente sinon. Un redémarrage d’horloge exige une nouvelle connexion/source.

Pour des signaux instrument, fournir ascan, dt_us > 0, t0_us et l’angle. L’amplitude utilise une échelle explicite, sans renormalisation automatique au maximum. Un secteur S-scan réel demande plusieurs profils sectoriels ; l’application n’en fabrique pas en l’absence de données reçues. Le paquet d’exemple porte example_only:true : il reste synthétique.

## 9. Importer un modèle et calculer un champ

Pièce / Importer STL/OBJ : indiquer unités et rotations, puis analyser le modèle. Un maillage fermé est nécessaire. Les coordonnées sont converties en mm et l’origine déplacée aux minima XYZ : conserver cette transformation pour une liaison à un tracker ou à un Twin externe. L’import CAO STEP natif n’est pas proposé dans ce fichier.

Coupe & champ : le champ géométrique est interactif ; le calcul scalaire se lance à la position choisie pour les cas plans compatibles. Déplacer la sonde revient au modèle interactif. Le scalaire ne remplace pas un calcul élastique complet ni la propagation dans le wedge. Conserver la provenance lors des comparaisons.

## 10. Démonstration conseillée et dépannage

Avant Fabien/Shaun : charger une soudure, choisir MWB puis PA, déplacer la sonde, acquérir quelques positions, mémoriser un écho et exporter JSON/PNG. Refaire sur un piquage pour expliquer les coordonnées développées. Montrer ensuite le suivi caméra en indiquant clairement sa portée XY.

Écran vide : vérifier WebGL et essayer Plan. Pas de profils : vérifier le contact, le mouvement, la source et l’état de relecture. Caméra refusée : vérifier autorisation, HTTPS/localhost et usage par une autre application. Pose refusée : lire séquence, horodatage, confiance, unités et source choisie. JSON sans défauts : relecture attendue ; charger une nouvelle pièce pour un nouvel exercice.

Les liens Nozzle et Soudure du Guide ouvrent les applications sources. Ils ne synchronisent pas automatiquement utilisateurs, acquisitions, repères ni indications. L’intégration à une véritable scène XR reste un chantier distinct, décrit dans le rapport de revue.
