# Revue de BYTE NDT — Atelier unifié de Fabien

**Auteurs / Authors : Jean-Michel Puybouffat et Fabien Dedieu.**
© 2026 Jean-Michel Puybouffat & Fabien Dedieu. Les composants tiers conservent leurs licences et attributions. / Third-party components retain their respective licences and credits.


Revue du 7 novembre 2026. Original : « byte ndt top .html », 12 663 637 octets. Empreinte SHA-256 dans CORRECTIONS.json. Original reçu conservé sans modification. Aucun fichier aube ni application Streamlit n’a été modifié. Aucun message envoyé à Fabien. La copie revue n’a pas été publiée.

## Conclusion

Le fichier est une base fonctionnelle de démonstration et de formation UT : atelier 3D, scénarios, acquisition simulée, écrans UT, exercices et interfaces d’entrée. Aucun blocage JavaScript n’a été observé dans les parcours testés. Les limites physiques importantes sont déjà décrites dans le Guide et les exports ; il faut conserver ces mentions.

Il s’agit d’un atelier autonome. Les applications Nozzle/Soudure sont citées et liées, mais leurs sessions, indications et résultats ne sont pas synchronisés automatiquement. Le suivi caméra est une commande XY d’un palpeur virtuel, avec Z/contact contraints. L’inspection statique n’a pas trouvé de demande de session immersive WebXR dans le code applicatif. L’affichage 3D et le suivi main sont donc une étape vers la réalité virtuelle/augmentée, pas une preuve d’intégration XR complète ni de jumeau mesuré.

La revue n’est pas une validation exhaustive de toutes les combinaisons, une qualification du calcul UT, ni une recette du matériel de Fabien.

## Tests réalisés et preuves

Environnement : Chromium automatisé, moteur WebGL logiciel, pages servies par interception locale à une origine localhost. Pas de connexion à une caméra personnelle, un instrument UT ni un serveur WebSocket réel. Les scripts et résultats JSON sont fournis pour reproduction.

| Contrôle | Résultat observé | Portée |
|---|---|---|
| Ouverture et rendu 3D | OK, aucune erreur JavaScript observée | Chromium du poste de revue |
| 14 panneaux dans chaque langue | 28 ouvertures OK | Guide, géométrie, sonde, parcours, indications, formation, rapport, champ, entrées, caméra, catalogue, matériaux, profils, import modèle |
| Huit familles de pièces | Chargement et profils numériques finis OK | Un cas de chaque famille |
| 40 configurations du catalogue | 40 chargements et validations OK dans la copie revue | Passage réel par la bibliothèque et sa résolution des maillages |
| Acquisition / mémorisation | Profil et point créés | Acquisition manuelle de base |
| Exercice aveugle | 10 positions acquises, remise et correction affichées | Relevé vide ; tests de saisie complète de tous les types non exhaustifs |
| Protection interface de la référence | getSettings sans défauts en mode aveugle | Pas une sécurité d’examen ; code local inspectable |
| JSON | Téléchargement et réimport réussis | Session stagiaire ouverte en relecture, 1 profil et 1 point conservés |
| CSV acquisitions / parcours | Fichiers téléchargés | Pas de validation de compatibilité Excel régionale |
| PNG | Fichier téléchargé | Quatre écrans UT |
| FR/EN | Bascule réelle et libellés des panneaux vérifiés | Pas de certification linguistique de chaque branche d’erreur |
| Persistance | Langue conservée ; acquisitions perdues au rechargement | Comportement documenté : exporter JSON |
| API externe | Pose et A-scan horodatés acceptés | Appels JavaScript, sans équipement physique |
| Rejet API | Séquence répétée et A-scan invalide refusés | Cas négatifs ciblés |
| Calcul scalaire | Worker terminé ; source scalar confirmée | Un cas plan, pas validation de fidélité physique |
| Caméra | Flux synthétique et initialisation du suivi démarrés | Non calibré ; fps suivi 0 en l’absence de main ; pas validation de précision |
| Largeurs 390 / 768 / 1920 px | Pas de débordement horizontal global | Ne garantit pas l’ergonomie tactile de tous les panneaux |

Fichiers de preuve : browser_results.json, flow_results_timestamp.json, extended_corrected_results.json et captures. extended_results.json contient une première vérification directe des paramètres : les cinq modèles maillés y échouent avant résolution, ce qui est attendu quand on contourne le chargeur de bibliothèque. Le test réel des 40 chargements de la copie corrigée les résout et réussit. Il ne faut pas rapporter ces cinq essais intermédiaires comme des défauts de l’application.

Le premier essai API avait volontairement/initialement omis timestamp_ms et a été refusé INVALID_TIME. L’essai corrigé fournit l’horodatage et réussit : cela confirme une exigence du protocole, pas une panne d’intégration.

## Corrections appliquées dans une copie

BYTE_NDT_ATELIER_REVUE.html conserve tous les moteurs, ressources et données embarquées. Quatre remplacements ciblés sont tracés dans CORRECTIONS.json :

- Le badge « XYZ EXTERNE » devient « EXTERNAL XYZ » en anglais.
- « Créneaux » devient « Balayage raster » pour rendre explicite le parcours automatique.
- Le Guide et la notification d’inversion utilisent le même terme français.

Aucun calcul, géométrie, protocole de données ou algorithme de notation n’a été modifié. La copie a été retestée : catalogue 40/40, bascule de langue, exercice, worker scalaire et initialisation caméra, sans erreur JavaScript observée.

## Recommandations à traiter avec Fabien

### Avant une démonstration publique

1. **Nommer correctement l’expérience.** Présenter « atelier UT 3D avec commande caméra » tant que le suivi réel, le recalage spatial et les fonctions XR ne sont pas validés. Conserver la distinction calculé / instrument.
2. **Prévenir la perte d’acquisitions.** Ajouter un avertissement visible à la fermeture, au rechargement et au changement de scénario si des acquisitions n’ont pas été exportées. Le navigateur ne conserve aujourd’hui que les paramètres et le texte du rapport. Prévoir ensuite une sauvegarde de session explicite, avec retour d’état.
3. **Recetter sur l’ordinateur de démonstration.** Tester permissions caméra, éclairage, déplacement connu, retour à l’origine, occultation et STOP. La revue ne remplace pas cette étape.
4. **Vérifier l’affichage des icônes.** Quelques symboles sont rendus comme carrés dans les captures Linux. Remplacer les glyphes de navigation importants par des SVG intégrés pour un rendu stable sur les postes cibles.
5. **Donner une procédure de reprise.** Un export stagiaire sans référence est une relecture ; ce n’est pas un fichier permettant de relancer librement le même exercice avec vérité. Le guide livré explique les deux variantes.

### Pour l’intégration des applications et le jumeau spatial

6. **Définir un contrat commun de session.** specimen_id, indication_id, opérateur, procédure, repère, unités, version de géométrie, version de lois focales, provenance des signaux et identifiant d’acquisition. L’événement actuel byte-ndt-plate-response et les objets ByteNDT/ByteNDTPlate sont un début d’interface, pas un bus de synchronisation entre trois applications.
7. **Conserver les vraies références.** Les scénarios générés ne doivent pas remplacer silencieusement les indications nominales Nozzle/Soudure/aube. Prévoir import contrôlé et correspondance des identifiants. Pour l’aube : racine test, 5/6 indications, C1/C2 et transformation d’unités doivent rester explicitement liés.
8. **Documenter les transformations.** Repère CAO → pièce réelle → tracker/caméra → scène ; mm/m, axes, origine, rotation, erreur de recalage et date du calibrage. L’import STL/OBJ translate l’origine aux minima XYZ : cette transformation doit être enregistrée pour un raccord à des données existantes.
9. **Choisir l’expérience XR visée.** Écran et caméra, AR sur tablette, casque immersif ou tracker physique ne demandent pas la même architecture. Définir le matériel, les degrés de liberté mesurés, le système de référence et un mode dégradé.
10. **Valider le vrai suivi.** Mesurer erreur de position/orientation, dérive, latence et comportement lors d’une perte de suivi dans l’accès réel. Sur aubes/piquages, un contrôleur plan ne mesure pas l’orientation 3D ni le contact.
11. **Valider l’adaptateur instrument.** Vérifier horodatage, séquences, unités, saturation, gain, zéro, fréquence d’échantillonnage, secteurs et reconnexion. Le code reçoit des A-scans, mais aucune compatibilité d’appareil spécifique n’est démontrée par cette revue.
12. **Conserver les moteurs distincts.** Les calculs géométrique et scalaire ont des hypothèses différentes ; ni l’un ni l’autre ne remplace une référence expérimentale et une procédure qualifiée. Une reconstruction pédagogique ne doit pas être présentée comme mesure de défaut réel.

## Traductions : observations

Les panneaux principaux FR/EN sont cohérents dans les essais. Restent des messages techniques issus d’exceptions JavaScript en anglais et des identifiants bruts de pièce/face dans certains rapports. Priorité : traduire le message humain, conserver un code technique séparé. Éviter la traduction des clés JSON du protocole.

Glossaire recommandé : probe = sonde/palpeur ; wedge = sabot ; nozzle = piquage ; gate = porte ; backwall echo = écho de fond ; lack of fusion = manque de fusion ; root crack = fissure de racine ; wall loss = perte d’épaisseur ; raster = balayage raster/en méandres. Pour des produits métalliques laminés, discuter « dédoublure » plutôt que « délaminage », selon le défaut visé. « Gain » et « amplitude relative » ne doivent pas être confondus avec une amplitude instrument étalonnée.

## Recette restante avec Fabien

- Démarrer la copie sur le PC cible et vérifier 3D, Plan, commandes et FR/EN.
- Démontrer une soudure puis un piquage ; acquérir, exporter, fermer et réimporter le JSON.
- Exporter un rapport PDF dans FR puis EN et examiner coupures, champs et unités. Le déclenchement d’impression n’a pas été testé par cette revue.
- Calibrer la caméra avec dimensions connues ; comparer plusieurs points, relever erreur et répétabilité, puis provoquer une perte de suivi.
- Tester un vrai paquet instrument / tracker et sa reconnexion ; aucune commande matérielle n’est envoyée par l’adaptateur fourni.
- Définir le flux de navigation entre atelier, Nozzle et Soudure : liens seuls ou session partagée ; ne pas annoncer une synchronisation avant recette.

## Reprise aube

La revue Fabien est un dossier séparé. Point conservé : copie Fusion LSB941_WOODENBLOCK_POSITIONNEMENT_V01 sauvegardée. Les deux voisines ne sont pas encore repositionnées de façon validée. Racine, indications et parcours restent les références. Enveloppe sonde-wedge 25³ mm, berceau 29,6 mm provisoire, ressort préréglé, verrouillage accessible du haut, ajutages embarqués et pompe péristaltique. Le passage scanner ne sera validé qu’après positionnement des voisines.

## Complément pour la réunion du lundi 9 novembre

Le manuel anglais est enrichi d’un scénario de démonstration, d’une liste de moyens vidéo et d’un cadrage du pilote automobile. La note DEMONSTRATION_LUNDI_FR_EN décrit une présentation de sept minutes, trois formats vidéo et un texte de narration anglais. Les vidéos restent à enregistrer.

Mentions ajoutées : Jean-Michel Puybouffat et Fabien Dedieu, métadonnée auteur, rubrique Auteurs et droits du Guide et rapport imprimable. Ces mentions préservent les attributions des composants tiers. Les moteurs UT sont inchangés.

L’anglais de l’interface et les textes du manuel ont été relus : conservation d’une terminologie technique cohérente (probe, wedge, gate, nozzle, shear wave, replay, ground truth). Le manuel anglais est autonome et ne demande pas de lire la version française. Les messages d’exception techniques restent un point de finition signalé à Fabien ; tous les messages de toutes les branches ne sont pas certifiés par la revue.
