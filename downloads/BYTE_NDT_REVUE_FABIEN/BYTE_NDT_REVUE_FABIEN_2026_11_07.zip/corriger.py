from pathlib import Path
import hashlib,json
src=Path('/workspace/attachments/938e0738-aa37-4c9f-8bc7-8f15b0a6c132/byte ndt top .html');s=src.read_text();changes=[]
patches=[("'XYZ EXTERNE'","t('XYZ EXTERNE','EXTERNAL XYZ')","Traduction du badge de suivi externe"),('data-fr="Créneaux"','data-fr="Balayage raster"','Libellé français du parcours automatique'),('Créneaux pilote un parcours.','Le balayage raster pilote un parcours.','Guide : nom du parcours automatique'),('Relance les créneaux.','Relance le balayage raster.','Notification : parcours automatique')]
for old,new,why in patches:
 count=s.count(old)
 if count:s=s.replace(old,new);changes.append({'ancien':old,'nouveau':new,'occurrences':count,'raison':why})
p=Path('/workspace/audit_fabien');(p/'BYTE_NDT_ATELIER_REVUE.html').write_text(s);(p/'CORRECTIONS.json').write_text(json.dumps({'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'changements':changes,'portee':'Traductions uniquement. Aucun calcul acoustique ni adaptateur ni geometrie modifies.'},indent=2,ensure_ascii=False));print(changes)
