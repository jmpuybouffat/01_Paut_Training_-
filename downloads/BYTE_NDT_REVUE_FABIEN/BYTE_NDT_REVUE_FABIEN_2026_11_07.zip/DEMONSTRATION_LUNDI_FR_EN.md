# Démonstration et réunion automobile — lundi 9 novembre 2026

Auteurs : Jean-Michel Puybouffat et Fabien Dedieu.
© 2026 Jean-Michel Puybouffat & Fabien Dedieu. Les composants tiers gardent leurs licences et attributions.

## Utilité pour l’équipe automobile

Oui, ce document interactif est utile pour montrer une démarche : objet 3D, actions de l’utilisateur, affichages cohérents, acquisition/relecture, formation et traçabilité. Le fichier autonome facilite une démonstration préparée ; le manuel anglais facilite sa prise en main internationale. Le PDF seul explique le fonctionnement, mais une courte vidéo et l’application manipulable rendent la proposition plus tangible.

L’application actuelle concerne les ultrasons. Elle ne prédit pas le comportement d’une voiture. La présenter comme preuve d’une architecture d’interaction et de formation, puis discuter d’un premier cas automobile mesurable. Ne pas promettre qu’un simple remplacement du modèle 3D fournit un Twin dynamique validé.

## Déroulé conseillé : 7 minutes

1. 1 minute : besoin du client et principe du jumeau — quel phénomène veut-on comprendre ou quelle décision veut-on améliorer ?
2. 3 minutes : démonstration UT préparée (soudure, mouvement, acquisition et relecture ; bref passage au nozzle).
3. 1 minute : distinguer simulation, mesure et suivi caméra plan ; expliquer ce qui reste à intégrer.
4. 2 minutes : proposer un pilote automobile basé sur un seul enregistrement réel et recueillir les critères de réussite.

Livrables à emporter : HTML décompressé, manuel anglais PDF, vidéo MP4 locale avec sous-titres anglais, JSON de démonstration exporté, une page de proposition automobile. Prévoir une version vidéo sans dépendance réseau. Aucun envoi à l’équipe n’a été fait par cette revue.

## Vidéos proposées

### Vidéo 1 — présentation en anglais, 90 secondes

0–15 s : logo, noms des auteurs, “Interactive ultrasonic inspection training”.
15–40 s : pièce soudée, déplacement du palpeur et réponse A/S-scan.
40–60 s : acquisition, B/C-scans et mémorisation.
60–75 s : rapport et relecture JSON.
75–90 s : nozzle et message “One shared workspace — calculated signals unless an instrument supplies measurements”.

Voix anglaise suggérée :

“BYTE NDT connects a three-dimensional specimen, probe motion and ultrasonic displays in one training workspace. The operator can explore welds and nozzles, acquire profiles, record findings and replay an exported session. In this demonstration, the signals are calculated. Instrument measurements require a compatible adapter. Camera control is available in a calibrated plane; full spatial tracking is a separate integration step. The same interaction approach can support other training domains, provided their physical models and data are validated.”

### Vidéo 2 — prise en main, 5 à 7 minutes

Bibliothèque → choix sonde → paramètres → déplacement → acquisition → lecture écrans → relevé → rapport → export → réimport. Finir par les limites et le Guide. Faire deux prises FR et EN ou une prise EN sous-titrée FR. Le scénario détaillé figure dans USER_GUIDE_EN.pdf.

### Vidéo 3 — caméra, 2 minutes après recette réelle

Montrer le plan et ses dimensions, les quatre coins, le déplacement connu, une perte de suivi et l’arrêt. Ne pas remplacer cette recette par la caméra synthétique utilisée pour les tests logiciels.

## Moyens nécessaires et critères avant enregistrement

- PC avec Chrome/Edge actuel, WebGL fonctionnel, écran 1080p ; OBS Studio ou outil équivalent, 1080p / 30 images/s.
- Microphone calme ; curseur visible ; textes lisibles ; notifications personnelles coupées.
- Pour le suivi : caméra fixe, lumière stable, plan coté et marqueur/main visible.
- Pour du réel : tracker/instrument et adaptateur testés ; sinon badge calculé conservé.
- Configuration et JSON préparés, essais de chargement/relecture, titres et noms d’auteurs visibles.
- Sous-titres anglais relus : wedge = sabot ; nozzle = piquage ; gate = porte ; shear wave = onde transversale ; tracking = suivi.
- Vérifier le MP4 final sur un second ordinateur ; garder une copie locale pour la réunion.

Ces vidéos sont des propositions de production ; elles ne sont pas encore enregistrées. Ni OBS ni un hébergement vidéo ne sont requis pour utiliser l’application elle-même.

## Pilote automobile proposé à discuter

Objectif initial possible : rejouer un virage instrumenté et comparer deux passages synchronisés. Commencer par la relecture avant une prédiction en temps réel.

Données à demander selon disponibilité : temps, trajectoire GNSS, vitesse, angle de volant, accélérations, vitesse de lacet, commandes frein/accélérateur ; plus tard débattements de suspension, vitesses de roues et autres mesures si le cas le justifie. Recueillir unités, taux d’échantillonnage, délai et qualité des capteurs.

Définir avec l’équipe : véhicule et configuration, manœuvre, repères, synchronisation temporelle, phénomène cible, vérité de référence, précision attendue et droits d’utilisation des données. Les modèles pneus/suspension/aérodynamique et leur identification sont des travaux propres au domaine automobile.

Message anglais pour lundi :

“The UT demonstrator shows how a shared 3D workspace can connect an object, user actions, acquired data and a traceable training workflow. It is not a vehicle-dynamics model. For a vehicle-behaviour Twin, we propose starting with synchronized replay of one instrumented manoeuvre, then adding and validating the physical model against measured runs.”

## Droits et attribution

La mention des auteurs demandée est ajoutée au Guide de l’application, aux rapports et aux manuels. Elle ne remplace pas un accord entre coauteurs sur leurs contributions, la licence de diffusion, l’exploitation commerciale ou les marques. Conserver les attributions des bibliothèques et ressources tierces. La revue ne détermine pas la titularité juridique de ces composants.
