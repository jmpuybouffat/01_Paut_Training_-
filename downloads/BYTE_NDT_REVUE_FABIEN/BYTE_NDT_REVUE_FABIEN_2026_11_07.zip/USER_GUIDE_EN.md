# BYTE NDT — Unified workspace: user guide

**Authors: Jean-Michel Puybouffat and Fabien Dedieu.**
© 2026 Jean-Michel Puybouffat & Fabien Dedieu. Third-party components retain their respective licences and credits.


Reviewed 7 November 2026. Open BYTE_NDT_ATELIER_REVUE.html in current Chrome/Edge on a desktop. Use HTTPS for shared deployment and camera/serial features; localhost is suitable for development. Embedded resources support local simulation. Source-app links need Internet.

## Workflow

1. Use FR/EN to select the language. Open Specimen library, search/filter, and load a specimen. There are 40 presets, 19 materials and 15 probe profiles. Export current work before replacing a scenario.
2. Select SE 0°, MWB or PA32. Open Advanced / Probe library for nominal settings, wedge dimensions, range and calibration. Set gates and specimen properties for the exercise.
3. With Mouse & keyboard selected, drag on the part/plan. Arrow keys move; Shift increases movement; Q/E changes heading; Space stores a response. Right-drag/orbit changes the view; the wheel zooms.
4. Acquire records profiles at spatial steps. Raster follows the configured path. STOP interrupts movement and acquisition. No motion means no new spatial coverage. Invalid geometric contact prevents acquisition.
5. Read A-scan time/amplitude; click to position the cursor. S-scan is a PA sector or a single-angle section in SE/MWB. B-scan shows acquired travel/time; C-scan shows acquired gate-A amplitudes. Visited positions do not prove complete acoustic coverage.
6. Store points, complete Report, and export JSON, CSV, PNG or Print/PDF. PNG contains the four UT displays. JSON is required to retain/replay acquisition profiles; browser persistence alone saves settings/report text, not the acquisition history after reload.

## Blind exercises and sessions

Select Blind exercise, specimen, difficulty and objective. Read the brief, acquire at least eight distinct positions, add proposed XYZ findings, then submit. Feedback compares proposals with scenario reference; it is not operator certification or part acceptance. The local code remains inspectable and is not a secure examination system.

A trainee JSON without ground truth opens in replay mode. A fully resumable instructor session requires training mode and truth enabled before exporting. Keep instructor/trainee files separate. Importing or loading a specimen may replace the active workspace: export first.

## Camera and real data

Open Track, allow the camera, choose finger/coloured marker, and calibrate four corners in the documented order: origin, X corner, XY corner, Y corner. Enter true plane dimensions. Keep camera/reference fixed and test known-distance motion and tracking loss before demonstration. Recalibrate whenever either moves.

Camera tracking is planar XY control of a virtual probe. True Z/contact are not measured. On cylindrical parts it controls an unwrapped surface, not measured 3D curvature. The review checked initialization with a synthetic camera only; real precision, lighting, occlusion and drift require a physical bench test.

Inputs supports a documented JavaScript API, NDJSON serial and WebSocket adapters. Select External sensor first. Provide increasing sequence and finite increasing timestamp_ms, position_mm, orientation, face and confidence. Use a consistent monotonic clock or explicitly select an epoch clock. Real UT data additionally needs ascan, dt_us, t0_us and angle; amplitude scaling is explicit. A measured pose without received echoes still produces calculated signals. An actual sector requires sector profiles. The example packet is labelled synthetic. Proprietary instruments require adapters and physical validation.

## Models, physics and integration

Import a closed STL/OBJ with explicit units/rotation. Import converts to mm and relocates the origin to XYZ minima; retain this transform for external tracking. Native STEP import is not implemented in this file.

Section & field provides geometric visualization and an on-demand scalar engine for compatible flat specimens. Moving the probe returns to the interactive model. Neither model supplies industrial qualification; scalar pressure is not calibrated instrument amplitude. Preserve signal provenance.

The Guide links to Nozzle and Soudure source applications. Those links do not synchronize sessions, identities, indications or coordinate frames. The supplied file is a standalone educational workspace; a complete XR/digital-twin integration requires additional development and acceptance testing.

## Troubleshooting

Blank 3D: check WebGL or use Plan. No acquisition: check contact, source, motion and replay state. Camera unavailable: inspect permission, secure context and other camera users. Rejected packet: check sequence, timestamp, confidence, dimensions and source. Lost acquisitions after reload: restore an exported JSON. Start each demo with a known specimen and preserve the final JSON/report.

## A repeatable five-minute demonstration

Before recording, choose one known weld specimen and one nozzle specimen. Record their dimensions, material, probe profile, refracted angle, frequency, gain, gate and scan range. Use the same settings when repeating the demonstration. Do not present a randomly generated case as a measured industrial reference.

1. **Introduce the workspace.** “This is an ultrasonic inspection training workspace. The 3D specimen, probe position and UT displays share one application state.”
2. **Inspect a weld.** Load a weld, choose MWB, move the probe and point out the A-scan. Switch to PA32 and explain the sector display. State whether the signals are calculated or received from an instrument.
3. **Acquire a short path.** Start acquisition, move over a small region and stop. Explain that B-scan and C-scan contain acquired profiles, and that visited positions do not by themselves establish acoustic coverage.
4. **Record the result.** Store a point, fill in the operator/procedure/report fields, export JSON and PNG, then demonstrate JSON replay.
5. **Show the nozzle.** Explain that control Y is the unwrapped circumferential coordinate, whereas external tracked poses use Cartesian XYZ.
6. **Optional camera segment.** Calibrate the plane, show controlled XY motion and intentionally interrupt tracking. Say: “The camera controls a virtual probe in a calibrated plane. It does not measure true probe height or surface contact.”

## Practical recording checklist

Use a desktop with reliable WebGL, current Chrome/Edge, a 1920 × 1080 display, a screen recorder such as OBS Studio, and a microphone or separately recorded narration. Record at 1080p, 30 frames per second with a visible pointer and legible text. Turn off personal notifications. Check that names and data in the recording are approved for sharing.

For camera demonstrations, add a fixed camera, stable lighting, a known-size calibration plane and a clearly visible finger or coloured marker. Show the calibration before the live movement. If demonstrating an instrument, connect and validate its adapter beforehand; otherwise retain the calculated-signal label.

Prepare an English script and subtitles. Review terminology, pronunciation, screen readability, signal provenance and the full export/replay sequence before publishing. Keep a local MP4 as a fallback for meetings with unreliable Internet. A recording illustrates a workflow; it does not establish tracking accuracy or physical model validity.

## What to say to an automotive team

This demonstrator can illustrate a shared interaction pattern: a 3D object, live or replayed inputs, synchronized displays, an exercise and a traceable report. It does not currently simulate vehicle dynamics, tyres, suspension, aerodynamics or driver behaviour.

A vehicle-behaviour Twin needs time-synchronized telemetry, explicit vehicle and track coordinate frames, a validated dynamics model, known sensor units/rates, calibration and comparisons against measured runs. A safe first automotive demonstration is replay of one recorded manoeuvre, with timestamp-linked position, speed, steering, acceleration and yaw rate where those signals are available. Define the target question and acceptance criteria with the team before selecting a model.
