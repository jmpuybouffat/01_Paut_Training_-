"""Couche d'affichage uniquement. Aucun changement des calculs ou resultats UT."""
from pathlib import Path
import json,inspect,functools
import numpy as np
import plotly.graph_objects as go
DATA=json.loads((Path(__file__).parent/'GEOMETRIE_AFFICHAGE_3_AUBES.json').read_text())
def _mesh(d,name=None):
 v=np.asarray(d['V'],float);f=np.arange(len(v)).reshape(-1,3)
 return go.Mesh3d(x=v[:,0],y=v[:,1],z=v[:,2],i=f[:,0],j=f[:,1],k=f[:,2],name=name or d['name'],color=d['color'],opacity=.16 if d['name'].startswith('Voisine') else .28,hoverinfo='skip',legendgroup='Contexte 3 aubes')
def _volume(pa,target,idx):
 p=np.asarray(pa,float)[idx];t=np.asarray(target,float)[idx];n=p-t;n=n/np.linalg.norm(n);y=np.asarray(pa,float)[min(len(pa)-1,idx+1)]-np.asarray(pa,float)[max(0,idx-1)];y=y-y.dot(n)*n;y=y/np.linalg.norm(y);x=np.cross(y,n)
 v=np.array([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],float)*12.5;v=v@np.column_stack([x,y,n]).T+p
 faces=np.array([[0,1,2],[0,2,3],[4,6,5],[4,7,6],[0,4,5],[0,5,1],[1,5,6],[1,6,2],[2,6,7],[2,7,3],[3,7,4],[3,4,0]])
 return go.Mesh3d(x=v[:,0],y=v[:,1],z=v[:,2],i=faces[:,0],j=faces[:,1],k=faces[:,2],color='#ffc332',opacity=.35,name='Volume global holder + PA + wedge (illustratif)',hoverinfo='name',legendgroup='Volume scanner')
def ajouter_contexte(fig,pa,target,shot=1):
 # Keep trace indexes intact: automatic source frames target the original traces.
 first=next((t for t in fig.data if t.type=='mesh3d'),None)
 central=[d for d in DATA if d['name'] in ['Racine centrale','Extension centrale']]
 v=np.concatenate([np.array(d['V']) for d in central]);f=np.arange(len(v)).reshape(-1,3)
 if first is not None:first.update(x=v[:,0],y=v[:,1],z=v[:,2],i=f[:,0],j=f[:,1],k=f[:,2],color='#dca536',opacity=.22,name='Aube centrale (contexte 3 aubes)')
 else:
  for d in central:fig.add_trace(_mesh(d))
 for d in DATA:
  if d not in central:fig.add_trace(_mesh(d))
 idx=max(0,min(len(pa)-1,int(shot)-1));vol_index=len(fig.data);fig.add_trace(_volume(pa,target,idx))
 if fig.frames:
  for frame in fig.frames:
   j=max(0,min(len(pa)-1,int(frame.name)-1));frame.data=tuple(frame.data)+(_volume(pa,target,j),);frame.traces=tuple(frame.traces or range(len(frame.data)-1))+(vol_index,)
 fig.add_annotation(text='Contexte trois aubes ; volume mecanique illustratif. Resultats UT source conserves.',xref='paper',yref='paper',x=0,y=-.12,showarrow=False,font=dict(size=10))
 return fig
def installer(ns):
 names=['make_true_scan3d_scene','make_3d_scene','make_2d_matrix_fan_scene','make_overview_scene','make_indication_focus_scene','make_auto_scan3d_animation']
 for name in names:
  original=ns[name]
  def wrap(fn):
   @functools.wraps(fn)
   def run(*args,**kwargs):
    bound=inspect.signature(fn).bind(*args,**kwargs);bound.apply_defaults();d=bound.arguments
    fig=fn(*args,**kwargs);shot=d.get('current_shot',d.get('shot',1))
    if 'validation_row' in d:shot=d['validation_row']['blind_shot']
    return ajouter_contexte(fig,d['pa'],d['target'],shot)
   return run
  ns[name]=wrap(original)
