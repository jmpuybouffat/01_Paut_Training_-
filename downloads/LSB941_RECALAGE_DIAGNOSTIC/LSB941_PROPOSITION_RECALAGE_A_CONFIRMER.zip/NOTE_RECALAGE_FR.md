# Aube 2 — diagnostic et proposition de recalage à confirmer

Le 7 novembre 2026. Source : LSB941_POSITIONNEMENT_ESSAI_21_5deg_.zip. Les fichiers source et le document Fusion de Jean-Michel sont inchangés.

## Résultat du diagnostic

Une rotation et une translation ne suffisent pas à superposer les surfaces correspondantes de la racine test et du pied du modèle voisin. Un ajustement diagnostique de similitude donne un facteur centrale vers voisine de 0,907652479, soit voisine vers centrale de 1,101743258 (+10,1743 %). Ce facteur relatif est distinct du facteur global 0,1 retenu pour lire les dimensions physiques de l'export.

La conclusion n'est pas déduite de la comparaison intrados/extrados 250,8 / 276,3 mm discutée précédemment. Elle repose sur des milliers de surfaces correspondantes du pied complet. La différence de référence physique reste à confirmer : des pièces volontairement différentes ne doivent pas être redimensionnées simplement pour coïncider.

Contrôle indépendant du sous-échantillon utilisé pour l'ajustement : 5 612 centres de facettes évalués, dont 5 572 avec correspondance de normales en similitude. Avec la base globale 0,1 : écart médian 1,8569 mm en recalage rigide seul ; 0,0457 mm avec similitude ; quantile 90 % 9,7894 mm / 0,1037 mm. Il subsiste des écarts locaux, notamment près des régions non communes. Ce n'est pas un contrôle métrologique du matériel réel.

## Essai sans correction d'échelle relative

Le centrage concentrique de l'aube 2 dans sa gorge a été calculé. Mais des sections entre faces CAO confirment encore des croisements avec la racine test maintenue fixe. Les longueurs de trois segments témoins sont 0,372 mm, 2,631 mm et 3,376 mm après application de la base globale 0,1. Ce sont des longueurs de courbes d'intersection, pas des profondeurs de pénétration.

## Proposition conservant la racine test

Le fichier PROPOSITION_ENSEMBLE_ECHELLE_A_CONFIRMER.step est une COPIE DE REVUE. Elle maintient la géométrie et le repère de la racine reçue, puis remet le bloc et les deux voisines à l'échelle relative de cette racine, avec recalage des pieds sur les axes des gorges et centrage des extrémités.

Cette proposition applique +10,1743 % à la périphérie. Elle est donc conditionnelle : elle ne doit être retenue que si la racine test actuelle est la bonne référence physique. À titre de repère, une même longueur périphérique de 250,825 mm devient environ 276,345 mm. Le montage ne doit pas être agrandi pour faire passer un scanner si le woodenblock physique correspond en réalité aux dimensions initiales.

Le STEP de revue conserve les coordonnées/échelle globale de l'export Fusion reçu. Il ne corrige pas en plus le facteur global 10. Ne pas confondre cette échelle native de document avec les valeurs physiques du présent rapport. Ouvrir la proposition dans un NOUVEAU document pour la comparer ; ne pas l'insérer dans le Twin existant, ce qui créerait des doublons.

Contrôles de maillage de la proposition : aucune intersection détectée entre les deux voisines et la racine/extension comparées (1 127 paires proches testées pour la voisine 1 ; 363 pour la voisine 2). La procédure est fournie. Ce résultat concerne les surfaces triangulées échantillonnées à la tolérance de travail ; il ne remplace pas un contrôle CAO exhaustif, les jeux mécaniques et un essai d'insertion réel.

Les contacts limites des pieds ont été équilibrés sur les cônes ajustés des gorges, sous hypothèse provisoire de contact nul. Aucun jeu industriel nominal n'a été fourni. Le bloc source est signalé invalide par le contrôle topologique CAO ; sa géométrie n'a pas été réparée dans la proposition. Cela limite la certification des contrôles volumiques et des appuis.

La racine dans le STEP provient du corps géométrique reçu avec deux petits volumes auxiliaires. Les 5/6 indications, les paramètres de l'application et les esquisses natives ne sont pas recréés ni certifiés par ce STEP. Ils doivent rester dans le document Fusion/Twin source. Le modèle de la voisine 1 masqué dans le dernier export est repris de l'archive antérieure de la même référence ; il est une proposition, pas une preuve de pose actuelle dans le document de Jean-Michel.

## Décision avant application

Choisir la référence dimensionnelle réelle :

- Racine test actuelle faisant foi : la proposition d'ajustement du bloc et des voisines peut être examinée et appliquée dans une copie native avec conservation des indications et parcours.
- Bloc et voisines actuels faisant foi : ne pas appliquer cette proposition ; il faut retrouver la version de racine de même échelle, ou autoriser une correction de son échelle et de toutes ses données associées.

Une seule cote réelle prise sur des points correspondants du pied/bloc permet de trancher. Les cordes intrados/extrados mesurées à des endroits différents ne suffisent pas à arbitrer la mise à l'échelle relative de deux pièces.

## Suite scanner

Après choix et contrôle du montage : deux scanners conformés aux surfaces d'appui, guidages suivant C1/C2, enveloppe PA+wedge 25 x 25 x 25 mm ; porte-sonde provisoire 29,6 mm ; ressort préréglé, verrouillage du haut, aspersion embarquée par pompe péristaltique et tuyaux/câble supérieurs. L'approche moule doit ménager insertion/retrait, jeux, course du ressort et dégagement des fluides. Aucune fabrication n'est validée par cette note.
